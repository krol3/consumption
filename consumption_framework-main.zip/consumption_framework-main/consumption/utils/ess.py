import logging
import re
from string import Template
from typing import Any, Dict

logger = logging.getLogger(__name__)


class ESSURLs:
    urls = {
        "ESS_BILLING_URL": Template(
            # Interpolate with organization_id and deployment_id
            "https://$cloud_endpoint/api/v1/billing/costs/%s/deployments/%s/items"
        ),
        "ESS_GET_DEPLOYMENT_URL": Template(
            # Interpolate with deployment_id
            "https://$cloud_endpoint/api/v1/deployments/%s"
        ),
        "ESS_LIST_BILLING_URL": Template(
            # Interpolate with organization_id
            "https://$cloud_endpoint/api/v1/billing/costs/%s/deployments"
        ),
        "ESS_LIST_DEPLOYMENTS_URL": Template(
            "https://$cloud_endpoint/api/v1/deployments"
        ),
        "ESS_SEARCH_DEPLOYMENTS_URL": Template(
            "https://$cloud_endpoint/api/v1/deployments/_search"
        ),
    }

    def __init__(self, api_host: str):
        self._cloud_endpoint = api_host

    def __getattr__(self, attr):
        return self.urls[attr].substitute(cloud_endpoint=self._cloud_endpoint)


class ESSResource:
    """
    Util class that parses the API response for an ESS resource and extracts the relevant information.
    This is used jointly for organization and deployment-level packages.
    """

    sku_regex = re.compile(
        r"(?P<provider>gcp|azure|aws)\.(?P<family>[^_]+)_(?P<region>[^_]+)_(?P<ram_per_zone>\d+)_(?P<zone_count>\d+)$"
    )

    def __init__(self, api_response: Dict[str, Any]):
        """
        Some examples of what the API response looks like for different hyperscalers:

        AWS:

        {
          "hours" : 1,
          "instance_count" : 38,
          "period" : {
            "start" : "2024-03-18T08:00:00.000Z",
            "end" : "2024-03-18T09:00:00.000Z"
          },
          "kind" : "elasticsearch",
          "price" : 426.816,
          "price_per_hour" : 426.816,
          "name" : "Cloud Enterprise, AWS us-east-1 (N. Virginia), aws.es.datahot.c6gd, 2280GB, 3AZ",
          "sku" : "Cloud-Enterprise_aws.es.datahot.c6gd_us-east-1_2334720_3"
        }

        Azure:

        {
          "hours" : 1,
          "instance_count" : 10,
          "period" : {
            "start" : "2024-03-18T08:00:00.000Z",
            "end" : "2024-03-18T09:00:00.000Z"
          },
          "kind" : "elasticsearch",
          "price" : 123.84,
          "price_per_hour" : 123.84,
          "name" : "Cloud Enterprise, Azure eastus2 (Virginia), azure.es.datahot.fsv2, 600GB, 3AZ",
          "sku" : "Cloud-Enterprise_azure.es.datahot.fsv2_azure-eastus2_614400_3"
        }

        GCP:

        {
          "hours" : 1,
          "instance_count" : 12,
          "period" : {
            "start" : "2024-03-18T08:00:00.000Z",
            "end" : "2024-03-18T09:00:00.000Z"
          },
          "kind" : "elasticsearch",
          "price" : 153.9072,
          "price_per_hour" : 153.9072,
          "name" : "Cloud Enterprise, GCP us-central1 (Iowa), gcp.es.datahot.n2.68x32x45, 768GB, 3AZ",
          "sku" : "Cloud-Enterprise_gcp.es.datahot.n2.68x32x45_gcp-us-central1_786432_3"
        }

        """

        # Save the raw attributes we're interested in
        self.type = api_response["kind"]
        self.name = api_response["name"]
        self.sku = api_response["sku"]
        self.quantity = api_response["hours"]
        self.rate = api_response["price_per_hour"]
        self.cost = api_response["price"]

        # Default values that will get overwritten if the SKU is known and parseable
        self.provider = "unknown"
        self.family = "unknown"
        self.region = "unknown"
        self.instance_count = 0

        # Identify the data tier based on name
        self.tier = "unknown"
        name_lower = api_response["name"].lower()

        if "hot" in name_lower or "high i/o" in name_lower:
            self.tier = "hot"
        elif "warm" in name_lower:
            self.tier = "warm"
        elif "cold" in name_lower:
            self.tier = "cold"
        elif "frozen" in name_lower:
            self.tier = "frozen"
        elif "master" in name_lower:
            self.tier = "master"
        elif "ml" in name_lower:
            self.tier = "ml"

        self.instance_price_per_hour = float(api_response["price_per_hour"])

        if api_response["sku"] == "unknown":
            logger.warning(
                f"SKU is unknown for {api_response}, skipping SKU enrichment"
            )
            return

        sku_match = self.sku_regex.search(api_response["sku"])
        if sku_match:
            # Extract the named groups from the regex match
            self.provider = sku_match.group("provider")
            self.family = sku_match.group("family")
            self.region = sku_match.group("region")
            self.ram_per_zone = int(sku_match.group("ram_per_zone")) / 1024
            self.zone_count = int(sku_match.group("zone_count"))
        else:
            logger.error(
                f"Could not parse \"{api_response['sku']}\" to get RAM per zone and AZ count, aborting"
            )
            return

        self.price_per_hour_per_gb = self.instance_price_per_hour / (
            self.ram_per_zone * self.zone_count
        )
        self.instance_count = api_response["instance_count"] * self.zone_count

    def asdict(self) -> Dict[str, Any]:
        """
        Returns the resource as a dictionary.
        This is used in the organization package to pass on the relevant info to the cost class.
        """
        return {
            "type": self.type,
            "name": self.name,
            "sku": self.sku,
            "provider": self.provider,
            "family": self.family,
            "region": self.region,
            "quantity": self.instance_count,
            "rate": self.rate,
            "cost": self.cost,
            "tier": self.tier,
        }
