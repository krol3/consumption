import logging
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, List, Tuple

from tqdm.contrib.logging import tqdm_logging_redirect

logger = logging.getLogger(__name__)


# Decorator that prints the stack trace of an exception
def print_stack_trace(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            traceback.print_exc()
            raise e

    return wrapper


class ParallelRetrier:
    """
    ThreadPoolExecutor-based class that will continuously retry the given tasks until they succeed.
    """

    def __init__(
        self,
        workers: int = 10,
        max_retry: int = 3,
        on_success_callback: Callable = lambda x: None,
        on_failure_callback: Callable = lambda x: None,
        on_success_params: Dict = {},
        on_failure_params: Dict = {},
    ):
        self.workers = workers
        self.max_retry = max_retry
        self.on_success_callback = on_success_callback
        self.on_failure_callback = on_failure_callback
        self.on_success_params = on_success_params
        self.on_failure_params = on_failure_params

    def run(
        self,
        tasks: List[Tuple[Callable, Dict]],
    ):
        """
        Run the given tasks until they succeed.
        """

        completed = 0

        with tqdm_logging_redirect(total=len(tasks), desc="Tasks") as pbar:
            with ThreadPoolExecutor(self.workers) as executor:
                tasks_map = {
                    executor.submit(print_stack_trace(function), **params): (
                        function,
                        params,
                        0,  # This is our retry counter
                    )
                    for function, params in tasks
                }

                while completed < len(tasks_map):
                    for result in as_completed(tasks_map):
                        if result.exception():
                            self.on_failure_callback(
                                result.exception(), **self.on_failure_params
                            )

                            # Get task parameters
                            function, params, past_retry_count = tasks_map[result]

                            # Check if we should retry
                            if past_retry_count >= self.max_retry:
                                logger.error(
                                    f"Task failed after {past_retry_count} retries - will stop retrying"
                                )
                                completed += 1
                                pbar.update(1)
                            else:
                                retry = executor.submit(
                                    print_stack_trace(function), **params
                                )
                                tasks_map[retry] = (
                                    function,
                                    params,
                                    past_retry_count + 1,
                                )
                        else:
                            self.on_success_callback(
                                result.result(), **self.on_success_params
                            )
                            completed += 1
                            pbar.update(1)

                        # Remove the task from consideration
                        del tasks_map[result]
