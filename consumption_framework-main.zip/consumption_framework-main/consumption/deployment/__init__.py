import logging
from collections import namedtuple
from datetime import datetime, timedelta
from typing import Callable, Dict, Optional

import pandas as pd
from elasticsearch import Elasticsearch
from elasticsearch.exceptions import NotFoundError
from elasticsearch.helpers import streaming_bulk

from ..utils import ParallelRetrier
from .ess import DeploymentFinder, get_elasticsearch_costs
from .monitoring_stats_connector import (NoResultsError,
                                         get_all_elasticsearch_ids)
from .on_prem_costs import get_on_prem_costs
from .processor import DeploymentDataProcessor

logger = logging.getLogger(__name__)

INDEX = "consumption"


def _data_already_exists(
    destination_es: Elasticsearch, start: datetime, end: datetime, elasticsearch_id: str
) -> bool:
    """
    Checks if data already exists for the given start, end and elasticsearch_id
    in the destination_es.
    """
    try:
        response = destination_es.search(
            index=INDEX + "*",
            query={
                "bool": {
                    "filter": [
                        {"term": {"elasticsearch_id": elasticsearch_id}},
                        {"term": {"dataset": "datastream"}},
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": start.isoformat(),
                                    "lt": end.isoformat(),
                                }
                            }
                        },
                    ]
                }
            },
            size=0,
            source=None,
        )
        if response["hits"]["total"]["value"] > 0:
            return True
        else:
            return False
    except NotFoundError:
        return False


def _process_function(
    source_es: Elasticsearch,
    destination_es: Elasticsearch,
    elasticsearch_id: str,
    start: datetime,
    end: datetime,
    price_df_function: Callable[[datetime, datetime], pd.DataFrame],
    monitoring_index_pattern: str,
    compute_usages: bool,
):
    """
    Processing function that hits the source_es between start and end
    to gather and aggregate monitoring data.
    price_df_function is a function that returns a DataFrame with the
    price information for the given time range.
    """

    # This could return an empty dataframe, which is fine
    # as the DeploymentDataProcessor will then simply skip cost computation.
    price_df = price_df_function(start, end)

    try:
        processor = DeploymentDataProcessor(
            es=source_es,
            elasticsearch_id=elasticsearch_id,
            from_ts=start,
            to_ts=end,
            price_df=price_df,
            monitoring_index_pattern=monitoring_index_pattern,
        )
    except NoResultsError as e:
        logger.warning(
            f"{elasticsearch_id} - {start.strftime('%Y-%m-%d %H:%M:%S')} "
            f"no results found, skipping: {e}"
        )
        return []

    res = list(processor.get_datastreams()) + list(processor.get_nodes())

    if compute_usages:
        res += list(processor.get_datastreams_usages())

    return res


def _exception_callback(exception):
    logger.error(f"Exception during execution: {exception}")


def _success_callback(
    result,
    destination_es: Elasticsearch,
    organization_id: str,
    organization_name: str,
    deployment_finder: DeploymentFinder,
):
    def _as_elasticsearch_doc(tuple: namedtuple) -> dict:
        source = tuple._asdict()
        source["@timestamp"] = source.pop("timestamp").isoformat()
        del source["index"]

        source["organization_id"] = organization_id
        source["organization_name"] = organization_name
        source["deployment_id"] = (
            deployment_finder.get_deployment_id(source["elasticsearch_id"])
            if deployment_finder
            else source["elasticsearch_id"]
        )

        # Some parameters are shared between node and datastream, and we use them
        # as base for the resulting document ID.
        doc_id = (
            source["dataset"]
            + "|"
            # On-prem can have empty organization_id
            + (source["organization_id"] or "")
            + "|"
            + source["deployment_id"]
            + "|"
            + source["@timestamp"]
            + "|"
            + source["tier"]
            + "|"
        )

        # The id generation process is different for Node and Index
        if source["dataset"] == "node":
            doc_id += source["id"]
        elif source["dataset"] == "datastream":
            doc_id += source["datastream"]
        elif source["dataset"] == "datastream_usage":
            doc_id += source["datastream"] + "|" + str(source["age_days"])
        else:
            raise ValueError(f"Unknown dataset: {source['dataset']}")

        return {
            "_id": doc_id,
            "_index": "consumption",
            "_source": source,
            "_op_type": "index",
        }

    ok_count = 0
    error_count = 0

    for ok, action in streaming_bulk(
        client=destination_es,
        raise_on_error=False,
        actions=(_as_elasticsearch_doc(entry) for entry in result),
    ):
        if ok:
            ok_count += 1
        else:
            logger.error(f"Failed to index document: {action}")
            error_count += 1

    logger.debug(f"Data upload completed: {ok_count} OK, {error_count} errors")


def monitoring_analyzer(
    source_es: Elasticsearch,
    destination_es: Elasticsearch,
    organization_id: Optional[str],
    organization_name: str,
    billing_api_key: Optional[str],
    from_ts: datetime,
    to_ts: datetime,
    threads: int,
    force: bool,
    compute_usages: bool,
    api_host: str,
    monitoring_index_pattern: str,
    on_prem_costs_dict: Optional[Dict[str, float]] = None,
):
    # Retrieve all elasticsearch_ids from the source_es
    elasticsearch_ids = get_all_elasticsearch_ids(
        es=source_es, index=monitoring_index_pattern, from_ts=from_ts, to_ts=to_ts
    )

    logger.debug(
        f"Identified {len(elasticsearch_ids)} deployments "
        f"in source cluster "
        f"between {from_ts.strftime('%Y-%m-%d %H:%M:%S')} "
        f"and {to_ts.strftime('%Y-%m-%d %H:%M:%S')}"
    )

    time_ranges = [
        (
            from_ts.replace(minute=0, second=0, microsecond=0) + timedelta(hours=i),
            from_ts.replace(minute=0, second=0, microsecond=0) + timedelta(hours=i + 1),
        )
        for i in range(0, int((to_ts - from_ts).total_seconds() / 3600))
    ]

    # Reverse the time ranges to start with the most recent ones
    time_ranges.reverse()

    logger.debug(
        f"Identified {len(time_ranges)} ranges "
        f"between {from_ts.strftime('%Y-%m-%d %H:%M:%S')} "
        f"and {to_ts.strftime('%Y-%m-%d %H:%M:%S')}"
    )

    finder = (
        DeploymentFinder(billing_api_key, organization_id, api_host=api_host)
        if (billing_api_key and organization_id)
        else None
    )

    # Static dataframe that represents costs, in case it's passed in the config
    on_prem_costs_df = (
        get_on_prem_costs(on_prem_costs_dict)
        if not (billing_api_key and organization_id)
        else None
    )

    all_params = [
        {
            "source_es": source_es,
            "destination_es": destination_es,
            "elasticsearch_id": elasticsearch_id,
            "start": from_ts,
            "end": to_ts,
            "monitoring_index_pattern": monitoring_index_pattern,
            "compute_usages": compute_usages,
            "price_df_function": (
                lambda a, b: get_elasticsearch_costs(
                    organization_id=organization_id,
                    deployment_id=finder.get_deployment_id(elasticsearch_id),
                    ess_api_key=billing_api_key,
                    from_ts=a,
                    to_ts=b,
                    api_host=api_host,
                )
            )
            if finder
            else lambda a, b: on_prem_costs_df,
        }
        for from_ts, to_ts in time_ranges
        for elasticsearch_id in elasticsearch_ids
        if (
            force
            or not _data_already_exists(
                destination_es, from_ts, to_ts, elasticsearch_id
            )
        )
    ]

    logger.debug(f"Identified {len(all_params)} processing combinations")

    on_success_params = {
        "destination_es": destination_es,
        "organization_id": organization_id,
        "organization_name": organization_name,
        "deployment_finder": finder,
    }

    retrier = ParallelRetrier(
        workers=threads,
        on_failure_callback=_exception_callback,
        on_success_callback=_success_callback,
        on_success_params=on_success_params,
    )

    retrier.run(
        tasks=[(_process_function, params) for params in all_params],
    )


__all__ = ["monitoring_analyzer"]
