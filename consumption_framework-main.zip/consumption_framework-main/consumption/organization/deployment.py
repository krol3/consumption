import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

import requests

from ..utils import ESSURLs
from .costs import DTSCost, ResourceCost

logger = logging.getLogger(__name__)


def _generate_ess_timestamps(ts: datetime) -> Tuple[datetime, datetime]:
    """
    Create the from and to timestamps for the ESS billing API.
    Returns a tuple of string (from, to) with the below format: "2023-05-03T16:00:00.000000"
    This corresponds to 1 hour prior to the given timestamp,
    as the costs are "full" only once the hour is over.
    """

    # Truncate the given timestamp to the hour to get the "to" timestamp
    to_timestamp = ts.replace(minute=0, second=0, microsecond=0)

    # Subtract 1 hour from the "to" timestamp to get the "from" timestamp
    from_timestamp = to_timestamp - timedelta(hours=1)

    # Specs overwrite for isoformat to force microseconds output (even if 0)
    return (from_timestamp, to_timestamp)


def get_all_deployments(
    organization_id: str,
    organization_name: str,
    billing_api_key: str,
    from_ts: datetime,
    to_ts: datetime,
    api_host: str,
):
    res = requests.get(
        url=ESSURLs(api_host).ESS_LIST_BILLING_URL % organization_id,
        headers={"Authorization": "ApiKey " + billing_api_key},
        params={
            "from": from_ts.isoformat(timespec="microseconds"),
            "to": to_ts.isoformat(timespec="microseconds"),
        },
    )

    res.raise_for_status()

    return [
        ESSDeployment(
            organization_id=organization_id,
            organization_name=organization_name,
            billing_api_key=billing_api_key,
            id=d["deployment_id"],
            name=d["deployment_name"],
            active_from=datetime.fromisoformat(  # This requires Python 3.11+ !
                d["period"]["start"]
            ),
            active_to=datetime.fromisoformat(d["period"]["end"]),
        )
        for d in res.json().get("deployments", [])
        if (
            d["deployment_id"] != ""
        )  # deleted deployments have an empty ID, we exclude them
    ]


@dataclass(kw_only=True)
class ESSDeployment:
    """
    Deployment from the list deployment ESS API
    Looks like:
    {
      "id" : "ID",
      "name" : "DEPLOYMENT_NAME",
      "resources" : [ RESOURCE_LIST ]
    }
    """

    id: str
    name: str

    # These timestamps can be passed to say when the deployment was active
    # They will be used to limit the billing API calls.
    active_from: Optional[datetime] = None
    active_to: Optional[datetime] = None

    organization_id: str
    organization_name: Optional[str]
    billing_api_key: str

    def analyze(
        self,
        from_ts: datetime,
        to_ts: datetime,
        api_host: str,
    ) -> List[ResourceCost]:
        """
        Get the billing information from ESS API.
        The costs are returned for the hour ending before the given timestamp.
        """

        # If we target a time during which the deployment was not active,
        # we return an empty list.
        # This means to_ts > self.active_from
        # or from_ts < self.active_to
        if (self.active_from and self.active_from > to_ts) or (
            self.active_to and self.active_to < from_ts
        ):
            logger.debug(
                f"Deployment {self.id} was not active "
                f"between {from_ts.strftime('%Y-%m-%d %H:%M:%S')} "
                f"and {to_ts.strftime('%Y-%m-%d %H:%M:%S')}"
            )
            return []

        deployment_costs = requests.get(
            url=ESSURLs(api_host).ESS_BILLING_URL % (self.organization_id, self.id),
            headers={"Authorization": "ApiKey " + self.billing_api_key},
            params={
                "from": from_ts.isoformat(timespec="microseconds"),
                "to": to_ts.isoformat(timespec="microseconds"),
            },
        )
        try:
            deployment_costs.raise_for_status()
        except requests.exceptions.HTTPError as e:
            logger.error(
                f'Failed to get costs for deployment "{self.id}" '
                f"from {from_ts.strftime('%Y-%m-%d %H:%M:%S')} "
                f"to {to_ts.strftime('%Y-%m-%d %H:%M:%S')}: {e}"
            )
            return []

        # Parameters passed down to DTS/Ressource cost dataclasses
        meta_parameters = {
            "time": from_ts.replace(minute=0, second=0, microsecond=0),
            "organization_id": self.organization_id,
            "organization_name": self.organization_name,
            "deployment_id": self.id,
            "deployment_name": self.name,
        }

        # Create the full list of costs of the deployment.
        # We aggregate DTS and Resource costs.
        costs = [
            DTSCost.from_api_response(
                dts,
                **meta_parameters,
            )
            for dts in deployment_costs.json()["data_transfer_and_storage"]
        ] + [
            ResourceCost.from_api_response(
                resource,
                **meta_parameters,
            )
            for resource in deployment_costs.json()["resources"]
        ]

        return costs
