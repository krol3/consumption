import logging
from datetime import datetime, timedelta

import eland as ed
import pandas as pd
from elasticsearch import Elasticsearch
from elasticsearch.exceptions import NotFoundError
from elasticsearch.helpers import streaming_bulk

from ..utils import ParallelRetrier
from .deployment import get_all_deployments

logger = logging.getLogger(__name__)

INDEX = "consumption"


class DataChecker:
    def __init__(
        self,
        destination_es: Elasticsearch,
        start: datetime,
        end: datetime,
        organization_id: str,
    ):
        try:
            self.check_df = (
                ed.DataFrame(
                    es_client=destination_es,
                    es_index_pattern=INDEX + "*",
                    columns=["@timestamp", "deployment_id", "organization_id"],
                )
                .es_query(
                    {
                        "bool": {
                            "filter": [
                                {"term": {"organization_id": organization_id}},
                                {"term": {"dataset": "deployment"}},
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gte": start.isoformat(),
                                            "lte": end.isoformat(),
                                        }
                                    }
                                },
                            ]
                        }
                    }
                )
                .groupby(["@timestamp", "deployment_id"])
                .count()
                .rename(columns={"organization_id": "doc_count"})
            )
        except (KeyError, NotFoundError, ValueError):
            logger.warning(
                "didn't find any data in the monitoring cluster "
                f"between {start.strftime('%Y-%m-%d %H:%M:%S')} "
                f"and {end.strftime('%Y-%m-%d %H:%M:%S')}, "
                "assuming no data exists"
            )
            self.check_df = pd.DataFrame()

    def already_exists(self, at_ts: datetime, deployment_id: str) -> bool:
        formatted = at_ts.replace(minute=0, second=0, microsecond=0).strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        return (formatted, deployment_id) in self.check_df.index


def _data_already_exists(
    destination_es: Elasticsearch,
    start: datetime,
    end: datetime,
    organization_id: str,
    deployment_id: str,
) -> bool:
    """
    Checks if data already exists for the given start, end and elasticsearch_id
    in the destination_es.
    """
    try:
        response = destination_es.search(
            index=INDEX + "*",
            query={
                "bool": {
                    "filter": [
                        {"term": {"organization_id": organization_id}},
                        {"term": {"deployment_id": deployment_id}},
                        {"term": {"dataset": "deployment"}},
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": start.isoformat(),
                                    "lt": end.isoformat(),
                                }
                            }
                        },
                    ]
                }
            },
            size=0,
            source=None,
        )
        if response["hits"]["total"]["value"] > 0:
            return True
        else:
            return False
    except NotFoundError:
        return False


def _exception_callback(exception):
    logger.error(f"Exception during execution: {exception}")


def organization_billing(
    destination_es: Elasticsearch,
    organization_id: str,
    organization_name: str,
    billing_api_key: str,
    from_ts: datetime,
    to_ts: datetime,
    threads: int,
    force: bool,
    api_host: str,
):
    deployments = get_all_deployments(
        organization_id=organization_id,
        organization_name=organization_name,
        billing_api_key=billing_api_key,
        from_ts=from_ts,
        to_ts=to_ts,
        api_host=api_host,
    )

    logger.debug(
        f"Identified {len(deployments)} deployments "
        f"for organization {organization_id} "
        f"between {from_ts.strftime('%Y-%m-%d %H:%M:%S')} "
        f"and {to_ts.strftime('%Y-%m-%d %H:%M:%S')}"
    )

    # Round the time ranges to the full hour
    time_ranges = [
        (
            from_ts.replace(minute=0, second=0, microsecond=0) + timedelta(hours=i),
            from_ts.replace(minute=0, second=0, microsecond=0) + timedelta(hours=i + 1),
        )
        for i in range(0, int((to_ts - from_ts).total_seconds() / 3600))
    ]

    # Reverse the time ranges to start with the most recent ones
    time_ranges.reverse()

    logger.debug(
        f"Identified {len(time_ranges)} ranges "
        f"between {from_ts.strftime('%Y-%m-%d %H:%M:%S')} "
        f"and {to_ts.strftime('%Y-%m-%d %H:%M:%S')}"
    )

    # TODO: instead of a "if force", make the DataChecker robust
    # to a lack of data in the target index.
    # Currently this crashes if there's no data and we don't force.
    if not force:
        checker = DataChecker(
            destination_es=destination_es,
            start=from_ts,
            end=to_ts,
            organization_id=organization_id,
        )

    all_params = [
        (d, {"from_ts": from_ts, "to_ts": to_ts, "api_host": api_host})
        for from_ts, to_ts in time_ranges
        for d in deployments
        if (force or not checker.already_exists(at_ts=from_ts, deployment_id=d.id))
    ]

    logger.debug(f"Identified {len(all_params)} processing combinations")

    # Create the success callback that will send data to the monitoring cluster
    def success_callback(result):
        ok_count = 0
        error_count = 0

        for ok, action in streaming_bulk(
            client=destination_es,
            raise_on_error=False,
            actions=(cost.as_elasticsearch_doc() for cost in result),
        ):
            if ok:
                ok_count += 1
            else:
                logger.error(f"Failed to index document: {action}")
                error_count += 1

        logger.debug(f"Data upload completed: {ok_count} OK, {error_count} errors")

    retrier = ParallelRetrier(
        workers=threads,
        on_failure_callback=_exception_callback,
        on_success_callback=success_callback,
    )

    retrier.run([(d.analyze, params) for d, params in all_params])


__all__ = ["organization_billing"]
